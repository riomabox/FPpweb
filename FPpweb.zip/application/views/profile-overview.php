<div class='p-overview'>
		<div class='profile-nama'>
			ID user
		</div>
		Menjadi member sejak [tanggal daftar]
		<div class='profile-last-active timestamp'>
			Last Active hh:mm:yy
		</div>
		<div class='profile-status'>
			Forum Statistik
		</div>
		<div class='row'>
			<div class='col-sm-2 p-status-head text-right'>
				Member Status
			</div>
			<div class='col-sm-10 p-status-column'>
				senior member bla bla bla
			</div>

			<div class='col-sm-2 p-status-head text-right'>
				jumlah Post
			</div>
			<div class='col-sm-10 p-status-column'>
				xxx
			</div>

			<div class='col-sm-2 p-status-head text-right'>
				Profil dilihat
			</div>
			<div class='col-sm-10 p-status-column'>
				x kali
			</div>

			<div class="col-sm-2 p-status-head text-right">
				Umur
			</div>
			<div class="col-sm-10 p-status-column">
				x tahun
			</div>

			<div class="col-sm-2 p-status-head text-right">
				Ulang Tahun
			</div>
			<div class="col-sm-10 p-status-column">
				dd-mm-yyyy
			</div>
		</div>
	</div>