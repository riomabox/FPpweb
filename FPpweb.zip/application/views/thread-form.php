<div class="comment">
	<div class="col-sm-12 c_input">
		<form>
            <textarea name="editor1" id="c_input_form" rows="10" cols="80"></textarea>
            <script>
                CKEDITOR.replace( 'c_input_form' );
            </script>
            <input type="submit" value="Komentar" class="btn btn-primary">
        </form>
    </div>
</div>