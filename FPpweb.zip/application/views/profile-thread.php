<?php echo "
	<div class=\"p-komentar\">
		<div class=\"profile-status\">
			Thread yang ditulis
		</div>";
		for ($i=0; $i < 100; $i++) { 
		echo "<div class=\"col-sm-12 c_head list_thread\">
			<a href=\"\" class=\"a_thread\">[Judul Thread]</a>
			<div class=\"timestamp\">[waktu post]</div>
		</div>";
		}
		
	echo "</div>";
?>