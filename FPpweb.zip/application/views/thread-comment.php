<div class="comment">
	<div class="col-sm-11 c_head">
		ID
	</div>
	<div class="col-sm-1 c_head text-right">
		nomer
	</div>
	<div class="col-sm-12 c_body">
		<div class="row">
			<div class="col-sm-2 c_profile text-center">
				Member
				<div class="c_foto">
					
				</div>
				xxx Post
			</div>
			<div class="col-sm-10 c_comment">
				<div class="timestamp">
					timestamp
				</div>
				<div class="c_comment_content">
					blabla
				</div>
			</div>
		</div>
	</div>
</div>