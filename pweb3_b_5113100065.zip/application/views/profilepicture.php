<?php
foreach($posts as $post)
 foreach($posts as $post)
?>